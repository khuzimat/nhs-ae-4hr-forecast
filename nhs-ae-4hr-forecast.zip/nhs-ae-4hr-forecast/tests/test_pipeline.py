import pandas as pd
import pytest

from src.features import add_performance, build_pairs
from src.load_data import load_all, parse_period
from src.train import walk_forward


@pytest.fixture(scope="module")
def data():
    return load_all()


def test_parse_period():
    assert parse_period("MSitAE-SEPTEMBER-2025") == pd.Timestamp("2025-09-01")


def test_no_total_rows_and_no_duplicates(data):
    assert not (data["org_code"].str.upper() == "TOTAL").any()
    assert not data.duplicated(["org_code", "month"]).any()


def test_performance_is_a_proportion(data):
    d = add_performance(data)
    assert d["perf"].between(0, 1).all()


def test_pairs_are_consecutive_months(data):
    p = build_pairs(data)
    gap = (p["target_month"].dt.year * 12 + p["target_month"].dt.month) - \
          (p["month"].dt.year * 12 + p["month"].dt.month)
    assert (gap == 1).all()
    # July -> August does not exist, so July must not appear as an origin month
    assert pd.Timestamp("2025-07-01") not in set(p["month"])


def test_walk_forward_never_uses_future(data):
    res = walk_forward(build_pairs(data))
    # every forecast is for a month after its origin, origin months are
    # strictly later than the first 3 training steps
    assert (res["target_month"] > res["origin_month"]).all()
    first_origin = build_pairs(data)["month"].min()
    assert res["origin_month"].min() > first_origin + pd.DateOffset(months=2)
