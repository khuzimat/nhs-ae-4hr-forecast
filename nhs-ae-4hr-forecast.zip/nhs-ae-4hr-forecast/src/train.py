"""Walk-forward evaluation of next-month Type 1 4-hour performance forecasts."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.features import FEATURES_CAT, FEATURES_NUM, build_pairs
from src.load_data import load_all

OUT = Path(__file__).resolve().parent.parent / "outputs"
MIN_TRAIN_STEPS = 3  # need at least 3 earlier month-to-month steps to train


def make_model(kind: str):
    pre = ColumnTransformer([
        ("num", StandardScaler(), FEATURES_NUM),
        ("cat", OneHotEncoder(handle_unknown="ignore"), FEATURES_CAT),
    ])
    reg = {
        "ridge": Ridge(alpha=10.0),
        "random_forest": RandomForestRegressor(n_estimators=300, min_samples_leaf=5,
                                               random_state=42, n_jobs=-1),
        "grad_boosting": HistGradientBoostingRegressor(max_depth=3, learning_rate=0.05,
                                                       max_iter=150, random_state=42),
    }[kind]
    return Pipeline([("pre", pre), ("reg", reg)])


def walk_forward(pairs: pd.DataFrame) -> pd.DataFrame:
    """Predict each step using ONLY earlier steps. Models predict the change
    (delta) from this month's value, so 'no change' is the natural fallback."""
    steps = sorted(pairs["month"].unique())
    rows = []
    for i, m in enumerate(steps):
        train = pairs[pairs["month"] < m]
        if train["month"].nunique() < MIN_TRAIN_STEPS:
            continue
        test = pairs[pairs["month"] == m]
        X_tr, X_te = train[FEATURES_NUM + FEATURES_CAT], test[FEATURES_NUM + FEATURES_CAT]
        preds = {"persistence": test["perf"].to_numpy()}
        preds["mean_change"] = test["perf"].to_numpy() + train["delta"].mean()
        for kind in ["ridge", "random_forest", "grad_boosting"]:
            model = make_model(kind).fit(X_tr, train["delta"])
            preds[kind] = test["perf"].to_numpy() + model.predict(X_te)
        for name, p in preds.items():
            rows.append(pd.DataFrame({
                "org_code": test["org_code"].values, "org_name": test["org_name"].values,
                "origin_month": m, "target_month": test["target_month"].values,
                "model": name, "actual": test["target"].values, "predicted": p}))
    return pd.concat(rows, ignore_index=True)


def summarise(res: pd.DataFrame) -> pd.DataFrame:
    def stats(g):
        err = g["predicted"] - g["actual"]
        return pd.Series({"MAE": err.abs().mean(), "RMSE": np.sqrt((err ** 2).mean()),
                          "n": len(g)})
    s = res.groupby("model").apply(stats, include_groups=False)
    return s.sort_values("MAE")


def make_charts(res: pd.DataFrame, summary: pd.DataFrame) -> None:
    OUT.mkdir(exist_ok=True)
    fig, ax = plt.subplots(figsize=(6, 3.6))
    s = summary["MAE"] * 100
    ax.barh(s.index[::-1], s.values[::-1], color="#4c78a8")
    for y, v in enumerate(s.values[::-1]):
        ax.text(v + 0.02, y, f"{v:.2f}", va="center", fontsize=9)
    ax.set_xlabel("Mean absolute error (percentage points)")
    ax.set_title("Next-month 4-hour performance: error by model")
    fig.tight_layout(); fig.savefig(OUT / "model_comparison.png", dpi=150); plt.close(fig)

    per_month = (res.assign(ae=(res.predicted - res.actual).abs())
                 .pivot_table(index="target_month", columns="model", values="ae") * 100)
    fig, ax = plt.subplots(figsize=(7, 3.8))
    for c in ["persistence", "ridge", "random_forest"]:
        ax.plot(per_month.index, per_month[c], marker="o", label=c)
    ax.set_ylabel("MAE (percentage points)"); ax.legend()
    ax.set_title("Error by month being forecast")
    fig.autofmt_xdate(); fig.tight_layout()
    fig.savefig(OUT / "error_by_month.png", dpi=150); plt.close(fig)

    best = summary.index.difference(["persistence", "mean_change"])
    best = summary.loc[best, "MAE"].idxmin()
    r = res[res.model == best]
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(r.actual * 100, r.predicted * 100, s=8, alpha=0.4, color="#4c78a8")
    lo, hi = 25, 100
    ax.plot([lo, hi], [lo, hi], color="grey", lw=1)
    ax.set_xlabel("Actual next-month performance (%)")
    ax.set_ylabel("Predicted (%)"); ax.set_title(f"{best}: predicted vs actual")
    fig.tight_layout(); fig.savefig(OUT / "predicted_vs_actual.png", dpi=150); plt.close(fig)


def main() -> dict:
    pairs = build_pairs(load_all())
    res = walk_forward(pairs)
    summary = summarise(res)
    OUT.mkdir(exist_ok=True)
    summary.to_csv(OUT / "model_comparison.csv")
    res.to_csv(OUT / "predictions.csv", index=False)
    make_charts(res, summary)
    print(summary.assign(MAE=lambda d: d.MAE * 100, RMSE=lambda d: d.RMSE * 100).round(3))
    return {"summary": summary, "results": res, "pairs": pairs}


if __name__ == "__main__":
    main()
