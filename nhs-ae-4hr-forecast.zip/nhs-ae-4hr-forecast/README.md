# Forecasting next-month A&E 4-hour performance for NHS trusts

A small, honest machine-learning project on **real NHS England data**: can we
predict how a major (Type 1) A&E department will perform on the 4-hour standard
*next month*, given this month's published figures?

**Short answer: not better than "next month will look like this month".**
That negative result is the point of the project - see *Results*.

## Data

NHS England, *A&E Attendances and Emergency Admissions* monthly provider-level
CSVs (10 months: May-Jul 2025 and Sep 2025-Mar 2026; April and August 2025 were
not used). Put the files in `data/raw/` as `ae_YYYY-MM.csv`. Data is published
by NHS England - check the licence/terms on their statistics page before
re-publishing the raw files (they are not committed if you add `data/raw/` to
`.gitignore`).

Unit of analysis: one **trust-month**, Type 1 departments only
(121 trusts with Type 1 activity in every month).

**4-hour performance** (my calculation) =
`1 - (over-4hr Type 1 + over-4hr booked Type 1) / (attendances Type 1 + booked Type 1)`.
Figures may differ slightly from NHS England's headline numbers.

## Method

- **Target:** the same trust's performance next calendar month.
- **Features (this month):** current performance, volume (log), booked-appointment
  share, Type 1 share of all A&E activity, rate of 12h+ and 4-12h decision-to-admit
  waits, emergency admission rate, performance relative to region, region.
- Models predict the *change* from this month, so "no change" is the fallback.
- **Validation:** expanding-window walk-forward. To forecast month *t+1*, models are
  trained only on month-to-month steps that finished earlier. First forecast needs
  3 earlier steps, giving 5 test months (Nov 2025 - Mar 2026) x 121 trusts = 605 forecasts.
- Only genuinely consecutive months are paired (July -> September is skipped).
- **Models:** persistence baseline, mean-change baseline, Ridge, Random Forest,
  Gradient Boosting.

## Results

| Model | MAE (pct points) | RMSE (pct points) |
|---|---|---|
| **Persistence (baseline)** | **3.32** | **4.50** |
| Mean change | 3.38 | 4.55 |
| Ridge | 3.41 | 4.57 |
| Gradient boosting | 3.43 | 4.58 |
| Random forest | 3.44 | 4.57 |

![models](outputs/model_comparison.png)

No model beats persistence. Trust performance is very sticky (month-to-month
correlation 0.91-0.97), so most of the signal is already in "this month's value".

Where the remaining error comes from: the **whole country moves together**.
Average change was +4.7 points into March 2026 and -2.6 into January 2026, and no
trust-level feature can anticipate that. Removing each month's national shift
would cut persistence MAE from 3.3 to 2.7 points (diagnostic only; not a usable forecast).

## Limitations

- Only 10 months, with gaps: 8 usable one-month steps, 5 test months. Too short
  for seasonality or lag features, and conclusions about more complex models are weak.
- Models trained on a few steps cannot learn winter/summer effects.
- Not a clinical or operational tool.

## Next steps

Add more months (NHS England publishes years of history) to test seasonality and lags;
forecast the national shift separately; try predicting breaches of the 4-hour target.

## Run

```
pip install -r requirements.txt
python -m src.train      # writes outputs/
python -m pytest -q
```
